package todoList.bindingModel;

public class TaskBindingModel {
    private String title;
    private String comments;

    public String getTitle() { return this.title; }

    public void setTitle(String title) { this.title = title; }

    public String getComments() { return this.comments; }

    public void setComments(String comments) { this.comments = comments; }
}
